<section class="shadow-sm">

<div class="container-fluid">

    <div class="row p-4 pt-5 partners">

        <h4 class="text-center sub-main-color ">Strategic Partners</h4>

    </div>



    <div class="row p-4 text-center">

        

        <div class="col-6  col-sm-6 col-md-2 p-2">

            <img src="assets/img/First-con.png " alt="">

        </div>

        <div class="col-6  col-sm-6 col-md-2 p-2">

            <img src="assets/img/HOB.png" alt="">

        </div>

        <div class="col-6  col-sm-6 col-md-2 p-2">

            <img src="assets/img/Rebate.jpg" alt="">

        </div>

        <div class="col-6  col-sm-6 col-md-2 p-2">

            <img src="assets/img/Pukka.png" alt="">

        </div>

        <div class="col-6  col-sm-6 col-md-2 p-2">

            <img src="assets/img/Spiffy.png" alt="">

        </div>

        

        <div class="col-6  col-sm-6 col-md-2 p-2">

            <img src="assets/img/First-con.png" alt="">

        </div>

    </div>

</div>

</section>
