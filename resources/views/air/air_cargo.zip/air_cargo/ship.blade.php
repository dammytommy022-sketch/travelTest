<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta name="description" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="worldshipping,worldShipExpress, Multipurpose, Business, Shipping, Cargo, logistic, " />
<meta name="author" content="HaytechSservice">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://maps.googleapis.com/maps/api/js?key={{ env('GOOGLE_MAPS_API_KEY') }}&libraries=places"></script>

<!-- Title -->
<title>W-shipExpress  - The World  Multipurpose Shipping Cargo Logistic </title>
<!-- Favicon -->
<link rel="shortcut icon" type="image/png" href="assets/images/fevicon.png">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/bootstrap.min.css') }}">
<!-- Font awesome CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/fontawesome.all.min.css') }}">
<!-- Animate CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/animate.min.css') }}">
<!-- OwlCarousel CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/owl.carousel.min.css') }}">
<!-- Magnific popup CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/fancybox.min.css') }}">
<!-- chat CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/chat.css') }}">
<!-- Slicknav CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/slicknav.min.css') }}">
<!-- Date picker CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/bootstrap-datetimepicker.min.css') }}">
<!-- Main CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/style.css') }}">
<!-- Responsive CSS -->
<link rel="stylesheet" href="{{ asset('assets/css/cargo/') }}responsive.css">
<!-- jQuery -->
<script src="{{ asset('assets/js/cargo/jquery-3.4.1.min.js') }}"></script>
</head>

<body>
<!-- Main Wrapper Start -->
<div class="main-wrapper"> 
  
  <!-- skiptocontent start ( This section for blind and Google SEO, Also for page speed )--> 
  <a id="skiptocontent" href="#maincontent">skip navigation</a> 
  <!-- skiptocontent End -->
  
   
  <header class="for-sticky"> 
    <!-- Header top area start -->
    <div class="header-top-area">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-8">
            <div class="top-contact"> <a href="#"><i class="fa fa-envelope"></i> worldexpressdelivery@gmail.com@gmail.com</a> <a href="#"><i class="fa fa-phone"></i> +88 01911 837404</a> <a href="#"><i class="far fa-clock"></i> 9:00AM to 8:00PM</a> </div>
          </div>
          <div class="col-12 col-lg-4 d-flex justify-content-center justify-content-lg-end">
            <div class="top-menu">
              <ul>
                <li><a href="customer-login.html"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="customer-register.html"><i class="fa fa-unlock-alt"></i> Registration</a></li>
              </ul>
            </div>
            <div class="language">
              <ul>
                <li><a href="#" title="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="assets/images/flag-1.png" alt=""/> EN</a>
                  <ul class="dropdown-menu">
                    <li><a href="" title=""><img src="assets/images/flag-1.png" alt=""/> EN</a></li>
                    <li><a href="" title=""><img src="assets/images/flag-2.png" alt=""/> TR</a></li>
                    <li><a href="" title=""><img src="assets/images/flag-3.png" alt=""/> BR</a></li>
                    <li><a href="" title=""><img src="assets/images/flag-4.png" alt=""/> SR</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Header top area End --> 
    
    <!-- Header area start -->
    <div class="header-area">
      <div class="container"> 
        <!-- Site logo Start -->
        <div class="logo"> <a href="index.html" title="W-shipping"><img src="assets/images/logo.png" alt="W-shipexpress"/></a> </div>
        <!-- Site logo end -->
        <div class="mobile-menu-wrapper"></div>
        <!-- Search Start 
        <div class="dropdown header-search-bar">
          <form action="index.html">
            <span class="" data-toggle="dropdown"><i class="fa fa-search" aria-hidden="true"></i></span>
            <input type="search" placeholder="kyewords.." class="dropdown-menu search-box">
          </form>
        </div>
         Search End -->
        
        <!-- Main menu start -->
        <nav class="mainmenu">
          <ul id="navigation">
            <li class="nav-active"><a href="#">Home</a>
              <ul>
                <li class="chaild-active"><a href="index.html">landpage</a></li>
              </ul>
            </li>
            <li><a href="#">Services</a>
              <ul>
                <li><a href="services.html">Service page</a></li>
                <li><a href="airfreight-services.html">Air Freight Shipping</a></li>
                <li><a href="occeanfreight-services.html">Ocean Freight Shipping</a></li>
                <li><a href="carfreight-services.html">Car Shipping</a></li>
              </ul>
            </li>
            <li><a href="#">Shipping</a>
              <ul>
                <li><a href="tracking.html">Track Shipment Progress</a></li>
                <li><a href="customer-login.html">Create New Shipment</a></li>
                <li><a href="customer-login.html">Shipment Calculator</a></li>
              </ul>
            </li>           <li><a href="#">Shipping</a>
              <ul>
                <li><a href="create-shipping.html">Create New Shipment</a></li>
                <li><a href="current-shipment.html">Current Shipment list</a></li>
                <li><a href="shipment-history.html">Shipment History</a></li>
              </ul>
            </li>
            <li><a href="#">Tracking</a>
              <ul>
                <li><a href="customer-login.html">Customer Login</a></li>
                <li><a href="customer-register.html">Customer Register</a></li>
                <li><a href="tracking.html">Tracking</a></li>
                <li><a href="tracking-result.html">Your shipment progress</a></li>
              </ul>
            </li>
            <li><a href="#">Blog</a>
              <ul>
                <li><a href="blog.html">Blog left sidebar</a></li>
                <li><a href="blog-another-page.html">Blog right sidebar</a></li>
                <li><a href="single-blog.html">Single Blog</a></li>
              </ul>
            </li>
            <li class="nav-active"><a href="#">pages</a>
              <ul>
                <li><a href="about.html">About Us</a></li>
                <li><a href="media.html">Media & Publications</a></li>
                <li><a href="freight-gallery.html">Freight Gallery</a></li>
                <li><a href="image-gallery.html">Image Gallery</a></li>
                <li><a href="typography.html">Typography</a></li>
                <li><a href="button-accordion.html">Button &amp; Accordion</a></li>
                <li><a href="community.html">Shipping Community</a></li>
                <li class="chaild-active"><a href="404.html">Error 404</a></li>
                <li><a href="sitemap.html">Sitemap</a></li>
                <li><a href="coming-soon.html">Coming Soon</a></li>
              </ul>
            </li>
            <li><a href="contact.html">Contuct Us</a></li>
          </ul>
        </nav>
        <!-- Main menu end --> 
      </div>
    </div>
    <!-- Header area End --> 
  </header>
  
  <!-- Breadcroumbs start -->
  <div class="wshipping-content-block wshipping-breadcroumb inner-bg-1">
    <div class="container">
      <div class="row">
        <div class="col-12 col-lg-7">
          <h1>Create New Shipment</h1>
          <a href="index.html" title="Home">Home</a> / Create New Shipment </div>
        <div class="col-12 col-lg-5 text-right">
          <h4>We freight to all over the world
            The best logistic company, <span>FAST</span> and <span>SAFELY!</span></h4>
        </div>
      </div>
    </div>
  </div>
  <!-- Breadcroumbs end --> 
  
  
  <!-- Create New Shipment Start -->
  <div class="wshipping-content-block shipping-block">
    <div class="container">
      <h2 class="heading2-border mt0">Create New Shipping</h2>
      <div class="row">
        <div class="shipping-form-block">
          <form class="steps" accept-charset="UTF-8" enctype="multipart/form-data">
            <!-- progressbar -->
            <ul id="progressbar">
              <li class="active">Where From</li>
              <li>Where Going</li>
              <li>What</li>
              <li>How</li>
              <li>Payment</li>
              <li>Review</li>
              <li>Complete</li>
            </ul>
            <!-- fieldsets Shipping From Start-->
            <fieldset>
              <h2 class="fs-title">Hello. Where are you shipping from? <a href="" title="" class="login-btn-form">Login</a></h2>
              <h3 class="fs-subtitle">* Indicates required field </h3>
              <div class="shipping-form">
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Country<sup>*</sup></label>
                      <select name="country" class="form-control">
                        <option>United States</option>
                        <option>Canada</option>
                        <option>France</option>
                        <option>Germany</option>
                        <option>Greece</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Company or Name<sup>*</sup></label>
                      <input type="text" class="form-control" name="cname" required="required" />
                      <span class="error1" style="display: none;"> <i class="error-log fa fa-exclamation-triangle"></i> </span> </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Contact<sup>*</sup></label>
                      <input type="text" class="form-control" name="contact" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Address<sup>*</sup></label>
                      <input type="text" class="form-control" name="address1" placeholder="Street Address" />
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="empty">&nbsp;</label>
                      <input type="text" class="form-control" name="address2" placeholder="Apartment, suite, unit, building, floor, etc." />
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="empty">&nbsp;</label>
                      <input type="text" class="form-control" name="address3" placeholder="Department, c/o, etc." />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Postal Code<sup>*</sup></label>
                      <input type="text" class="form-control" name="post"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>City<sup>*</sup></label>
                      <input type="text" class="form-control" name="city"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Other Address Information</label>
                      <input type="text" class="form-control" name="other-address" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="slide-label">Is this a residential address?</label>
                      <div class="slide-redio">
                        <input type="checkbox" value="None" id="slide-radio0" name="check" checked />
                        <label for="slide-radio0"></label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>E-mail <sup>*</sup></label>
                      <input type="email" class="form-control" name="email"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Telephone<sup>*</sup></label>
                      <input type="text" class="form-control" name="tel"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Ext.</label>
                      <input type="text" class="form-control" name="ext" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="checkbox">
                      <input type="checkbox" name="remember" id="send-update" class="css-checkbox" />
                      <label for="send-update" class="css-label">Send updates on this shipment</label>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="slide-label">Save as new entry </label>
                      <div class="slide-redio">
                        <input type="checkbox" value="None" id="slide-radio1" name="check" checked />
                        <label for="slide-radio1"></label>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="slide-label">Use this as my default address </label>
                      <div class="slide-redio">
                        <input type="checkbox" value="None" id="slide-radio2" name="check" checked />
                        <label for="slide-radio2"></label>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="slide-label">Add a Different Return Address</label>
                      <div class="slide-redio">
                        <input type="checkbox" value="None" id="slide-radio3" name="check" checked />
                        <label for="slide-radio3"></label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <input type="button" name="next" class="next action-button" value="Continue" />
              <input type="reset" name="cancel" class="action-button btn-red" value="Cancel Shipment" />
            </fieldset>
            <!-- fieldsets Shipping From end--> 
            
            <!-- fieldsets Shipping going Start-->
            <fieldset>
              <h2 class="fs-title">Where is your shipping going? <a href="" title="" class="login-btn-form">Login</a></h2>
              <div class="row">
                <div class="col-12 col-lg-4">
                  <div class="ship-address">
                    <h4>Ship from <a href="" title="Edit" class="btn-edit">Edit</a></h4>
                    <p>Lorem Ipsum is simply dummy text<br>
                      of the printing and typesetting industry</p>
                  </div>
                </div>
                <div class="col-12 col-lg-4">
                  <div class="ship-address">
                    <h4>Return to <a href="" title="Edit" class="btn-edit">Edit</a></h4>
                    <p>Lorem Ipsum is simplydummy text of the<br>
                      printing and typesetting industry</p>
                  </div>
                </div>
              </div>
              <h3 class="fs-subtitle">* Indicates required field </h3>
              <div class="shipping-form">
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <label>Country<sup>*</sup></label>
                    <select name="country2" class="form-control">
                      <option>United States</option>
                      <option>Canada</option>
                      <option>France</option>
                      <option>Germany</option>
                      <option>Greece</option>
                    </select>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Company or Name<sup>*</sup></label>
                      <input type="text" class="form-control" name="cname2" required="required"/>
                      <span class="error1" style="display: none;"> <i class="error-log fa fa-exclamation-triangle"></i> </span> </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Contact<sup>*</sup></label>
                      <input type="text" class="form-control" name="contact2" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Address<sup>*</sup></label>
                      <input type="text" class="form-control" name="address4" placeholder="Street Address" />
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="empty">&nbsp;</label>
                      <input type="text" class="form-control" name="address5" placeholder="Apartment, suite, unit, building, floor, etc." />
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label class="empty">&nbsp;</label>
                      <input type="text" class="form-control" name="address6" placeholder="Department, c/o, etc." />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Zip Code<sup>*</sup></label>
                      <input type="text" class="form-control" name="zip"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>City<sup>*</sup></label>
                      <input type="text" class="form-control" name="city2"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>State<sup>*</sup></label>
                      <input type="text" class="form-control" name="other-address" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>E-mail <sup>*</sup></label>
                      <input type="email" class="form-control" name="email2"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Telephone<sup>*</sup></label>
                      <input type="text" class="form-control" name="tel2"/>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="form-group">
                      <label>Ext.</label>
                      <input type="text" class="form-control" name="ext2" />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                  </div>
                </div>
              </div>
              <input type="button" name="previous" class="previous action-button" value="Previous" />
              <input type="button" name="next" class="next action-button" value="Continue" />
              <input type="reset" name="cancel" class="action-button btn-red" value="Cancel Shipment" />
            </fieldset>
            <!-- fieldsets Shipping going end--> 
            
            <!-- fieldsets package Start-->
            <fieldset>
              <h2 class="fs-title">What kind of packaging are you using? <a href="" title="" class="login-btn-form">Login</a></h2>
              <h3 class="fs-subtitle">* Indicates required field </h3>
              <div class="shipping-form">
                <div class="row">
                  <div class="col-12 col-lg-8">
                    <div class="row">
                      <div class="col-12 col-lg-6">
                        <div class="form-group">
                          <label>Packaging Type<sup>*</sup></label>
                          <div class="input-comment">
                            <select name="country2" class="form-control">
                              <option>Customer packaging</option>
                              <option>2kg</option>
                              <option>10kg</option>
                              <option>20kg</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-12 col-lg-6">
                        <div class="form-group">
                          <label>Weight<sup>*</sup></label>
                          <div class="input-comment">
                            <input type="text" class="form-control" name="weight" required="required" />
                            <span class="error1" style="display: none;"> <i class="error-log fa fa-exclamation-triangle"></i> </span> <span class="field-comment">lbs</span> </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12 col-lg-6">
                        <div class="form-group">
                          <label>Length</label>
                          <div class="input-comment">
                            <input type="text" class="form-control" name="length"/>
                            <span class="field-comment">in</span></div>
                        </div>
                      </div>
                      <div class="col-12 col-lg-6">
                        <div class="form-group">
                          <label>Width</label>
                          <div class="input-comment">
                            <input type="text" class="form-control" name="width"/>
                            <span class="field-comment">in</span></div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12 col-lg-6">
                        <div class="form-group">
                          <label>Height</label>
                          <div class="input-comment">
                            <input type="text" class="form-control" name="length"/>
                            <span class="field-comment">in</span></div>
                        </div>
                      </div>
                      <div class="col-12 col-lg-6">
                        <div class="form-group">
                          <label>Declared value</label>
                          <div class="input-comment">
                            <input type="text" class="form-control" name="width"/>
                            <span class="field-comment">USD</span></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-lg-4">
                    <div class="what-package"><img src="assets/images/package.jpg" alt=""/></div>
                  </div>
                </div>
              </div>
              <input type="button" name="previous" class="previous action-button" value="Previous" />
              <input type="button" name="next" class="next action-button" value="Continue" />
              <input type="reset" name="cancel" class="action-button btn-red" value="Cancel Shipment" />
            </fieldset>
            <!-- fieldsets package end--> 
            
            <!-- fieldsets pick up Start-->
            <fieldset>
              <h2 class="fs-title">How would you like to ship? <a href="" title="" class="login-btn-form">Login</a></h2>
              <h3 class="fs-subtitle">* Indicates required field </h3>
              <div class="shipping-form dropoff-block">
                <h3>Whould you like us to pick up your shipment?</h3>
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item"><a class="nav-link active" href="#no-drop" aria-controls="no-drop" role="tab" data-toggle="tab">No I'll drop it off</a></li>
                  <li class="or-text">--or--</li>
                  <li class="nav-item"><a class="nav-link" href="#yes-drop" aria-controls="yes-drop" role="tab" data-toggle="tab">Yes pick up my shipment</a></li>
                </ul>
                <div class="tab-content">
                  <div role="tabpanel" class="tab-pane active" id="no-drop">
                    <div class="row">
                      <div class="col-12 col-lg-4">
                        <div class="form-group">
                          <label>Dropoff date:</label>
                          <div class="datepicker-group">
                            <input type="text" class="form-control datetimepicker1" placeholder="Date" />
                            <div class="datepicker-icon"><i class="fa fa-calendar-alt"></i></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <h3>When would like it delivered?</h3>
                    <div class="row">
                      <div class="col-12 col-lg-4">
                        <div class="form-group">
                          <label>Date and short details:</label>
                          <input type="text" class="form-control" name="sDetails" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div role="tabpanel" class="tab-pane" id="yes-drop">
                    <div class="row">
                      <div class="col-12 col-lg-4">
                        <div class="form-group">
                          <label>Pickup date:</label>
                          <div class="datepicker-group">
                            <input type="text" class="form-control datetimepicker1" placeholder="Date" />
                            <div class="datepicker-icon"><i class="fa fa-calendar-alt"></i></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="review">
                      <h3>Pickup Address <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                      <p>Lorem Ipsum is simply dummy text<br>
                        of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                    <div class="review">
                      <h3>Pickup Details <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                      <p>Your pickup window: 9:00AM - 7:00PM<br>
                        Pickup location: Front Door</p>
                    </div>
                  </div>
                </div>
              </div>
              <input type="button" name="previous" class="previous action-button" value="Previous" />
              <input type="button" name="next" class="next action-button" value="Continue" />
              <input type="reset" name="cancel" class="action-button btn-red" value="Cancel Shipment" />
            </fieldset>
            <!-- fieldsets package end--> 
            
            <!-- fieldsets payment Start-->
            <fieldset>
              <h2 class="fs-title">How would like to pay? <a href="" title="" class="login-btn-form">Login</a></h2>
              <h3 class="fs-subtitle">* Indicates required field </h3>
              <div class="shipping-form">
                <div class="form-group">
                  <div class="row">
                    <div class="col-12 col-lg-4">
                      <label>Card Type<sup>*</sup></label>
                      <select name="cardType" class="form-control">
                        <option>Select One</option>
                        <option>Paypal</option>
                        <option>Visa</option>
                        <option>Master</option>
                        <option>American express</option>
                      </select>
                    </div>
                    <div class="col-12 col-lg-4">
                      <div class="we-accept"> <img src="assets/images/card-paypal.png" alt=""/> <img src="assets/images/card-visa.png" alt=""/> <img src="assets/images/card-master.png" alt=""/> <img src="assets/images/card-discover.png" alt=""/> <img src="assets/images/card-amex.png" alt=""/> </div>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-12 col-lg-4">
                      <label>Card Number<sup>*</sup></label>
                      <input type="text" class="form-control" name="address1" placeholder="Street Address"  required="required" />
                      <span class="error1" style="display: none;"> <i class="error-log fa fa-exclamation-triangle"></i> </span> </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-12 col-lg-4">
                      <label>Exparation<sup>*</sup></label>
                      <select name="exparation" class="form-control">
                        <option>Select Month</option>
                        <option>January</option>
                        <option>February</option>
                        <option>March</option>
                      </select>
                    </div>
                    <div class="col-12 col-lg-4">
                      <label class="empty">&nbsp;</label>
                      <select name="exparation2" class="form-control">
                        <option>Select Year</option>
                        <option>January</option>
                        <option>February</option>
                        <option>March</option>
                      </select>
                    </div>
                    <div class="col-12 col-lg-4">
                      <label>CVV<sup>*</sup></label>
                      <input type="text" class="form-control" name="other-address" />
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-12 col-lg-4">
                      <label class="slide-label">Billing Address</label>
                      <div class="checkbox">
                        <input type="checkbox" name="remember" id="same-bill" class="css-checkbox" />
                        <label for="same-bill" class="css-label">Send updates on this shipment</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <h3>Duties and Taxes</h3>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
                  <div class="row">
                    <div class="col-12 col-lg-4">
                      <label class="slide-label">Use a promo code?</label>
                      <div class="slide-redio">
                        <input type="checkbox" value="None" id="slide-radio4" name="check" checked />
                        <label for="slide-radio4"></label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <input type="button" name="previous" class="previous action-button" value="Previous" />
              <input type="button" name="next" class="next action-button" value="Continue" />
              <input type="reset" name="cancel" class="action-button btn-red" value="Cancel Shipment" />
            </fieldset>
            <!-- fieldsets payment Start--> 
            
            <!-- fieldsets Review Start-->
            <fieldset>
              <h2 class="fs-title">Let's make sure everyting is in order</h2>
              <div class="shipping-form">
                <div class="review">
                  <h3>Where <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                  <div class="row">
                    <div class="col-12 col-lg-4">
                      <div class="ship-address">
                        <h4>Ship from</h4>
                        <p>Lorem Ipsum is simply dummy text<br>
                          of the printing and typesetting industry</p>
                      </div>
                    </div>
                    <div class="col-12 col-lg-4">
                      <div class="ship-address">
                        <h4>Ship to</h4>
                        <p>Lorem Ipsum is simplydummy text of the<br>
                          printing and typesetting industry</p>
                      </div>
                    </div>
                    <div class="col-12 col-lg-4">
                      <div class="ship-address">
                        <h4>Return to</h4>
                        <p>Lorem Ipsum is simplydummy text of the<br>
                          printing and typesetting industry</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="review">
                  <h3>What <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                  <h5>Shipment information</h5>
                  <ul>
                    <li><b>Actual Weight:</b> 60 lbs</li>
                    <li><b>Total Bilable Weight:</b> 60 lbs</li>
                  </ul>
                  <h5>Package information</h5>
                  <ul>
                    <li><b>Weight:</b> 60 lbs</li>
                    <li><b>Dimensions:</b> 17x13x11 in</li>
                    <li><b>Declared value:</b> $100</li>
                  </ul>
                </div>
                <div class="review">
                  <h3>How <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                  <h5>Service Selection</h5>
                  <p>It has survived not only five centuries,</p>
                  <h5>Arrival</h5>
                  <p>Mon, Nov6, 2017, End of the day</p>
                </div>
                <div class="review">
                  <h3>Aditional Option <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                  <p>N/A</p>
                </div>
                <div class="review">
                  <h3>Payment <a href="" title="Edit" class="btn-edit">Edit</a></h3>
                  <h5>Bill Shipping Charge to:</h5>
                  <p>Paypal</p>
                  <h5>Bill Duties and Taxes to:</h5>
                  <p>Receive Company name</p>
                  <h5>Enter Promo Code:</h5>
                  <div class="promoCode-input">
                    <input type="text" class="form-control" name="sDetails" />
                  </div>
                </div>
                <div class="review">
                  <div class="checkbox">
                    <input type="checkbox" name="remember" id="trems" class="css-checkbox" />
                    <label for="trems" class="css-label">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</label>
                  </div>
                </div>
              </div>
              <input type="button" name="previous" class="previous action-button" value="Previous" />
              <input type="button" name="next" class="next action-button" value="Continue" />
            </fieldset>
            <!-- fieldsets payment Start-->
            <fieldset>
              <div class="shipping-form">
                <h1 class="tanks-message">Thank You For Create Shipping</h1>
              </div>
              <input type="submit" name="submit" class="submit action-button" value="Submit" />
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Create New Shipment end --> 
  

  <!-- Footer start -->
  <footer class="site-footer"> 
    <!-- Footer Top start -->
    <div class="footer-top-area">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-6 col-lg-3">
            <div class="footer-wiz">
              <h3 class="footer-logo"><img src="assets/images/footer-logo.jpg" alt="footer logo"/></h3>
              <p>It was popularised in the 1980s with the release of Letraset sheets containing.</p>
              <ul class="footer-contact">
                <li><i class="fa fa-phone"></i> +88 01911 837404</li>
                <li><i class="fa fa-envelope"></i>worldexpressdelivery@gmail.com@gmail.com</li>
                <li><i class="fa fa-fax"></i> +88 02 123456</li>
              </ul>
            </div>
            <div class="top-social bottom-social"> <a href="#"><i class="fab fa-facebook-f"></i></a> <a href="#"><i class="fab fa-twitter"></i></a> <a href="#"><i class="fab fa-youtube"></i></a> <a href="#"><i class="fa fa-rss"></i></a> </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3">
            <div class="footer-wiz footer-menu">
              <h3 class="footer-wiz-title">Quick Links</h3>
              <ul>
                <li><a href="about.html">Company Overview</a></li>
                <li><a href="services.html">Our Services</a></li>
                <li><a href="contact.html">Contact Us</a></li>

              </ul>
            </div>
          </div><!--
          <div class="col-12 col-md-6 col-lg-3">
            <div class="footer-wiz footer-menu">
              <h3 class="footer-wiz-title">Usefull Links</h3>
              <ul>
                <li><a href="create-shipping.html">Create Shipping</a></li>
                <li><a href="tracking.html">Tracking</a></li>
                <li><a href="shipment-history.html">Shipment History</a></li>
                <li><a href="typography.html">Typography</a></li>
                <li><a href="button-accordion.html">Button Accordion</a></li>
                <li><a href="tracking-result.html">Tracking Result</a></li>
              </ul>
            </div>
          </div>-->
          <div class="col-12 col-md-6 col-lg-3">
            <div class="footer-wiz">
              <h3 class="footer-wiz-title">Opening Hours</h3>
              <ul class="open-hours">
                <li><span>Mon to Fri:</span> <span class="text-right">09:30AM to 05:30PM</span></li>
                <li><span>Sun:</span> <span class="text-right">Closed</span></li>
              </ul><!--
              <div class="newsletter">
                <form action="index.html">
                  <input type="text" placeholder="Enter your email" value="" class="news-input">
                  <button type="submit" value="" class="news-btn"><i class="fa fa-location-arrow"></i></button>
                </form>-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- footer top end --> 
    
    <!-- copyright start -->
    <div class="footer-bottom-area">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-6 wow fadeInLeft">Copyright © 2020 <span>WorldShippingExpress</span>. All Rights Reserved</div>
          <div class="col-12 col-lg-6 text-right wow fadeInRight">Design & Development By: <a href="#" title="Haytechservice" target="_blank">Haytechservice</a></div>
        </div>
      </div>
    </div>
    <!-- copyright end --> 
  </footer>
</div>
<!-- Main Wrapper end --> 
<script src="{{ asset('assets/js/cargo/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/form-step.js') }}"></script>
<script src="{{ asset('assets/js/cargo/active.js') }}"></script>
<script src="{{ asset('assets/js/cargo/popper.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/tether.js') }}"></script>
<script src="{{ asset('assets/js/cargo/jquery.validate.js') }}"></script>
<script src="{{ asset('assets/js/cargo/jquery.filterizr.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/datetimepicker-moment.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/bootstrap-datetimepicker.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/jquery.slicknav.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/wow-1.3.0.min.js') }}"></script>
<script src="{{ asset('assets/js/cargo/youtube-background.js') }}"></script>
<script src="{{ asset('assets/js/cargo/chat.js') }}"></script>
<script src="{{ asset('assets/js/cargo/coming-soon.js') }}"></script>

</body>
</html>