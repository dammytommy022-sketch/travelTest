<head>
    <meta name="csrf-token" content="{{ csrf_token() }}"> 
    <!-- ASSETS -->
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/line-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/jquery.fancybox.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/animate.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/animated-headline.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/jquery-ui.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/flag-icon.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/style.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/mobile.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/app/themes/default/assets/css/childstyle.css') }}">

    <script src="{{ asset('assets/app/themes/default/assets/js/jquery/jquery.min.js') }}"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <!-- PACEJS -->
    <script src="../cdn.jsdelivr.net/npm/pace-js%40latest/pace.min.js"></script>
    <!-- Include jQuery UI -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <!-- RTL -->

    <style>
        /* Optional: Style for autocomplete suggestions */
        .autocomplete-suggestions {
            border: 1px solid #ccc;
            max-height: 350px;
            overflow-y: auto;
            position: absolute;
            background: #fff;
            z-index: 1000;
        }
        .autocomplete-suggestion {
            padding: 10px;
            cursor: pointer;
        }
        .autocomplete-suggestion:hover {
            background: #ddd;
        }
        .widget_cover{
            padding: 100px;
            padding-top: 100px;  
        }

        @media only screen and (max-width: 985px) {
            .widget_cover {
                padding: 10px;
            }
        }
        @media only screen and (max-width: 885px) {
            .widget_cover {
                padding: 0px;
            }
        }

        #loading-screen {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Transparent black background */
            z-index: 9999; /* Ensure it's above other content */
            text-align: center;
        }

        #loading-screen img {
            margin-top: 15%; /* Adjust this value to center the image vertically */
            max-width: 40%;
            max-height: 40%;
        }

        @media (max-width: 768px) {
            #loading-screen img {
                margin-top: 20%; /* Adjust for smaller screens */
            }
        }        
        .datepicker table tr td.day.old,
        .datepicker table tr td.day.new {
            visibility: hidden;
        }

        .new-room-selection-dropdown {
            border: 1px solid #ccc;
            padding: 15px;
            background-color: white;
            display: none;
            position: absolute; /* Set to absolute to exceed parent width */
            right: 0; /* Align with the left of the parent */
            width: 250px; /* This exceeds the parent's width */
            z-index: 10; /* Ensure it appears on top if necessary */
        }

        

        .new-room-controls {
            display: block;
            justify-content: space-between;
        }

        .new-adults, .new-children {
            margin-right: 10px;
        }

        .new-input-group {
            display: flex;
            align-items: center;
        }

        .new-input-group button {
            width: 30px;
            height: 30px;
            background-color: #f1f1f1;
            border: none;
        }

        .new-input-group input {
            width: 40px;
            text-align: center;
        }

        .new-add-room-btn, .new-done-btn {
            margin-top: 10px;
            padding: 5px 20px;
            background-color: #0d1883;
            border: none;
            cursor: pointer;
            color: white;
        }


    </style>
</head>

<body>
    <section class=" widget_cover"  style="background-image: url('{{ asset('public/assets/image/slide.jpg') }}');"> 
        <div class="container-fluid" id="cover">
            <div class="card ">
                <div style="" id="fadein">
                    <form autocomplete="off" id="my-form" class="main_search" action="{{ route('air.hotelpost')}}" method="POST">
                        {{ csrf_field() }}
                        <div class="row contact-form-action g-1">
                            <div class="col-lg-4 col-md-12 ">
                                <div class="input-box input-items">
                                    <label class="label-text">Hotel</label>
                                    <div class="form-group">
                                        <span class="la la-hotel form-icon"></span>
                                        <input class="form-control" type="search" id="keyword" placeholder="Search Country, City, Hotel" name="location"  value="" multiple required>
                                        <input type="hidden" id="extraData" name="hotel_regionID" value="">
                                        <div id="suggestions" class="col-lg-12 autocomplete-suggestions"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <div class="input-box">
                                    <label class="label-text">Check-In </label>
                                    <div class="form-group">
                                        <span class="la la-calendar form-icon"></span>
                                        <input class="depart form-control" id="departure" name="check-in"
                                            type="text" placeholder="mm/dd/yyyy" required>
                                            
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <div class="input-box">
                                    <label class="label-text">Check-Out</label>
                                    <div class="form-group">
                                        <span class="la la-calendar form-icon"></span>
                                        <input class="returning form-control dateright border-top-l0"
                                            name="check-out" type="text" id="return" placeholder="mm/dd/yyyy ">
                                            
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3">
                                <div class="input-box">
                                    <label class="label-text">Room & Guest </label>
                                    <div class="form-group">
                                        <div class="dropdown dropdown-contain">
                                            <span class="la la-bed form-icon"></span>
                                            <input type="hidden" name="room" id="no_room" value="1">
                                            <input type="hidden" name="guest" id="no_guest" value="1">

                                            <a class="dropdown-toggle dropdown-btn travellers-new ps-5" href="#" role="button"
                                            data-toggle="dropdown" aria-expanded="false">
                                                <p style="font-size:12px;">
                                                    <span class="new-rooms">1</span> Room,
                                                    <span class="new-guests">1</span> Guests
                                                </p> 
                                            </a>

                                            <div class="dropdown-menu new-room-selection-dropdown">
                                                <!-- Container where the rooms will be added -->
                                                <div id="rooms-container">
                                                    <!-- Room 1 -->
                                                    <div class="new-room" data-room="1">
                                                        
                                                        <h6>Room 1</h6>
                                                        <div class="new-room-controls">
                                                            <div class="row">
                                                                <div class="col-6">
                                                                    <div class="new-adults">
                                                                        <!-- Adults -->
                                                                        <label>Adults</label>
                                                                        <div class="new-input-group">
                                                                            <button class="new-minus-adult">-</button>
                                                                            <input type="number" value="1" min="1" class="new-adults-count">
                                                                            <button class="new-plus-adult">+</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-6 ">
                                                                    <div class="new-children">
                                                                        <!-- Children -->
                                                                        <label>Children (0 - 17)yrs</label>
                                                                        <div class="new-input-group ">
                                                                            <button class="new-minus-child">-</button>
                                                                            <input type="number" value="0" min="0" class="new-children-count">
                                                                            <button class="new-plus-child">+</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Remove Room Button (hidden for the first room) -->
                                                        <div class="text-end">
                                                            <small>
                                                                <a href="#" class="remove-room" style="color: red; display: none;"> Remove Room</a>
                                                            </small>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-6 pt-2">
                                                        <!-- Add Room Button -->
                                                        <small>
                                                            <a href="#" id="add-room-btn">+ Add a room</a>
                                                        </small>
                                                    </div>
                                                    <div class="col-6 text-end">
                                                        <!-- Done Button -->
                                                        <button class="new-done-btn">Done</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="col-lg-2 col-md-3 mx-auto">
                                    <div class="btn-search text-center">
                                        <!-- <input type="submit" class=" w-100 btn-lg " value="Book Your Flight" data-style="zoom-in"> -->
                                        <button class="theme-btn w-100 mx-auto" type="submit">Search</button>
                                    </div>
                                </div>
                            </div>

                            
                       </div> 
                            
                    </form>
                </div>
                @if(session('error'))
                    <span class="alert text-warning">
                        {{ session('error') }}
                    </span>
                @endif

            </div>
        </div>
    </section>
    
    
   
    <script>
        document.querySelector('.travellers-new').addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector('.new-room-selection-dropdown').classList.toggle('show');
        });

        document.querySelectorAll('.new-minus').forEach(function (button) {
            button.addEventListener('click', function () {
                let input = this.nextElementSibling;
                if (input.value > 1) {
                    input.value--;
                }
            });
        });

        document.querySelectorAll('.new-plus').forEach(function (button) {
            button.addEventListener('click', function () {
                let input = this.previousElementSibling;
                input.value++;
            });
        });

        document.querySelector('.new-add-room-btn').addEventListener('click', function () {
            // Logic to add more room selections
            alert('Add room functionality here');
        });

        document.querySelector('.new-done-btn').addEventListener('click', function () {
            // Logic when Done is clicked
            alert('Done clicked');
        });

    </script>
    <script>
        $(document).ready(function(){
            $('#departure', '#return').datepicker({
                format: 'mm/dd/yyyy',
                autoclose: true,
                todayHighlight: true,
                // Hide dates of previous and next months
                beforeShowDay: function(date) {
                    var currentDate = new Date();
                    var currentMonth = currentDate.getMonth();
                    var dateMonth = date.getMonth();
                    var isCurrentMonth = dateMonth === currentMonth;
                    return isCurrentMonth ? 'active' : 'disabled';
                }
            });
        });
        

    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Make sure you load your countrys.js file -->
    <script src="{{ asset('assets/js/countrys.js') }}"></script>
    <!-- The hidden input field to store the extra data -->
    <script>
        // Function to find country name by its code
        function getCountryNameByCode(code) {
            const country = countries.find(c => c.code === code);
            return country ? country.name : code; // Return country name or fallback to code
        }

        document.getElementById('keyword').addEventListener('keyup', _.debounce(function() {
            const keyword = this.value;
            if (keyword.length < 3) {
                document.getElementById('suggestions').innerHTML = ''; // Clear suggestions
                return;
            }
        
            $.ajax({
                url: '/autocomplete', 
                method: 'POST',
                data: {
                    query: keyword,
                    _token: '{{ csrf_token() }}' 
                },
                success: function(response) {
                    const suggestionsDiv = document.getElementById('suggestions');
                    suggestionsDiv.innerHTML = ''; 
        
                    if (response.error) {
                        suggestionsDiv.innerHTML = `<div class="alert alert-danger">${response.error}</div>`;
                        return;
                    }
        
                    const hotels = response.data.hotels || [];
                    const regions = response.data.regions || [];
        
                    if (hotels.length === 0 && regions.length === 0) {
                        suggestionsDiv.innerHTML = '<div class="alert alert-warning">No suggestions found</div>';
                        return;
                    }
        
                    let regionHtml = '<small><b>Regions:</b></small><br>';
                    let hotelHtml = '<small><b>Hotels:</b></small><br>';
        
                    regions.forEach(region => {
                        const countryCode = region.country_code;
                        const countryName = getCountryNameByCode(countryCode);
                        regionHtml += `<strong class="autocomplete-suggestion d-block" data-id="${region.id}" data-type="region" data-country-code="${countryCode}" data-name="${countryName}" data-value="${region.name}, ${countryName}"><i class="fa-solid fa-city"></i> ${region.name}, ${countryName}</strong>`;
                    });
        
                    hotels.forEach(hotel => {
                        hotelHtml += `<strong class="autocomplete-suggestion d-block" data-id="${hotel.id}" data-type="hotel" data-value="${hotel.name}" data-name="${hotel.name}"><i class="fas fa-hotel"></i> ${hotel.name}</strong>`;
                    });
        
                    suggestionsDiv.innerHTML = `<div>${regionHtml} ${hotelHtml}</div>`;
        
                    suggestionsDiv.querySelectorAll('.autocomplete-suggestion').forEach(item => {
                        item.addEventListener('click', function() {
                            const name = this.getAttribute('data-name');
                            const id = this.getAttribute('data-id');
                            const type = this.getAttribute('data-type');
                            const datavalue = this.getAttribute('data-value');
        
                            document.getElementById('keyword').value = datavalue;
                            document.getElementById('extraData').value = `${id}, ${type}`;
                            document.getElementById('suggestions').innerHTML = ''; 
                        });
                    });
                },
                error: function(xhr, status, error) {
                    console.error('Error:', status, error);
                    document.getElementById('suggestions').innerHTML = '<div class="alert alert-danger">An error occurred while fetching suggestions</div>';
                }
            });
        }, 300)); // Debounce by 300ms

    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const roomsContainer = document.getElementById('rooms-container');
            let roomCount = 1; // Initial room count (since Room 1 is already there)

            // Function to update the total rooms and guests
            function updateTotal() {
                const rooms = document.querySelectorAll('.new-room'); // Total number of rooms
                const totalRooms = rooms.length;
                let totalGuests = 0;

                rooms.forEach(room => {
                    const adults = parseInt(room.querySelector('.new-adults-count').value);
                    const children = parseInt(room.querySelector('.new-children-count').value);
                    totalGuests += adults + children; // Add adults and children
                });

                // Update the total room and guest count in the UI
                document.querySelector('.new-rooms').textContent = totalRooms;
                document.querySelector('.new-guests').textContent = totalGuests;
                document.getElementById('no_room').value = totalRooms;
                document.getElementById('no_guest').value = totalGuests;
            }

            // Function to add a new room
            function addRoom() {
                roomCount += 1; // Increment room count

                // Clone the first room (Room 1)
                const newRoom = document.querySelector('.new-room').cloneNode(true);
                
                // Update the room label (e.g., Room 2, Room 3, etc.)
                newRoom.setAttribute('data-room', roomCount);
                newRoom.querySelector('h6').textContent = `Room ${roomCount}`;

                // Reset inputs in the cloned room
                newRoom.querySelector('.new-adults-count').value = 1; // Reset adult count to 1
                newRoom.querySelector('.new-children-count').value = 0; // Reset children count to 0

                // Show the "Remove Room" button for dynamically added rooms
                newRoom.querySelector('.remove-room').style.display = 'inline'; 

                // Append the new room to the container
                roomsContainer.appendChild(newRoom);

                // Attach event listener to the remove button of the newly added room
                newRoom.querySelector('.remove-room').addEventListener('click', function (event) {
                    event.preventDefault();
                    removeRoom(newRoom);
                });

                // Attach event listeners to the new controls
                attachEventListeners(newRoom);

                // Update total rooms and guests
                updateTotal();
            }

            // Function to remove a room
            function removeRoom(roomElement) {
                if (roomsContainer.children.length > 1) { // Ensure at least one room remains
                    roomElement.remove();
                    updateTotal();
                } else {
                    alert("You must have at least one room.");
                }
            }

            // Attach event listeners to room controls
            function attachEventListeners(room) {
                const adultsInput = room.querySelector('.new-adults-count');
                const childrenInput = room.querySelector('.new-children-count');

                // Update total when adults input value changes
                adultsInput.addEventListener('change', updateTotal);

                // Update total when children input value changes
                childrenInput.addEventListener('change', updateTotal);

                // Handle minus button for adults
                room.querySelector('.new-minus-adult').addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent form submission
                    let currentVal = parseInt(adultsInput.value);
                    if (currentVal > 1) {
                        adultsInput.value = currentVal - 1;
                        updateTotal();
                    }
                });

                // Handle plus button for adults
                room.querySelector('.new-plus-adult').addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent form submission
                    let currentVal = parseInt(adultsInput.value);
                    adultsInput.value = currentVal + 1;
                    updateTotal();
                });

                // Handle minus button for children
                room.querySelector('.new-minus-child').addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent form submission
                    let currentVal = parseInt(childrenInput.value);
                    if (currentVal > 0) {
                        childrenInput.value = currentVal - 1;
                        updateTotal();
                    }
                });

                // Handle plus button for children
                room.querySelector('.new-plus-child').addEventListener('click', function (event) {
                    event.preventDefault(); // Prevent form submission
                    let currentVal = parseInt(childrenInput.value);
                    childrenInput.value = currentVal + 1;
                    updateTotal();
                });
            }

            // Attach event listener to the first room's remove button (hidden but still needs event listener)
            document.querySelector('.remove-room').addEventListener('click', function (event) {
                event.preventDefault();
                removeRoom(document.querySelector('.new-room'));
            });

            // Attach event listener to the "Add Room" button
            document.getElementById('add-room-btn').addEventListener('click', function(event) {
                event.preventDefault(); // Prevent default link behavior
                addRoom();
            });

            // Attach event listener to the "Done" button to close the dropdown
            document.querySelector('.new-done-btn').addEventListener('click', function(event) {
                event.preventDefault(); // Prevent default button behavior
                document.querySelector('.dropdown-menu').classList.remove('show'); // Close the dropdown
            });

            // Attach event listeners to the first room's controls
            attachEventListeners(document.querySelector('.new-room'));

            // Initial update total
            updateTotal();
        });
    </script>

    

    <script src="{{ asset('assets/app/themes/default/assets/js/jquery-ui.js') }}"></script>
    <!-- <script src="../app/themes/default/assets/js/bootstrap.bundle.min.js"></script> -->
    <script src="{{ asset('assets/app/themes/default/assets/js/jquery.fancybox.min.js') }}"></script>
    <script src="{{ asset('assets/app/themes/default/assets/js/jquery.countTo.min.js') }}"></script>
    <script src="{{ asset('assets/app/themes/default/assets/js/quantity-input.js') }}"></script>
    <script src="{{ asset('assets/app/themes/default/assets/js/select2.js') }}"></script>
    <script src="{{ asset('assets/app/themes/default/assets/js/main.js') }}"></script>
    <script src="{{ asset('assets/app/themes/default/assets/js/app.js') }}"></script>
    
    
    

</body>